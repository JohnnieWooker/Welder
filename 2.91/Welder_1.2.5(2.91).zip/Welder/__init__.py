'''
Copyright (C) 2016 Łukasz Hoffmann
johnniewooker@gmail.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

'''

import bpy
import bgl
import blf
import gpu
from gpu_extras.batch import batch_for_shader
import bmesh
import os 
import bpy.utils.previews
from bpy.props import StringProperty, EnumProperty
from bpy.types import AddonPreferences
from bpy_extras.view3d_utils import (
    region_2d_to_vector_3d,
    region_2d_to_origin_3d,
    region_2d_to_location_3d
)

from . import utils
from . import operators

debug=False

bl_info = {
    "name": "Welder",
    "author": "Łukasz Hoffmann",
    "version": (1,2,5),
    "location": "View 3D > Object Mode > Tool Shelf",
    "wiki_url": "https://gumroad.com/l/lQVzQ",
    "tracker_url": "https://blenderartists.org/t/welder/672478/1",
    "blender": (2, 91, 0),
    "description": "Generate weld along the edge of intersection of two objects",
    "warning": "",
    "category": "Object",
    }

def surfaceBlendUpdate(self, context):
    if (context.active_object != None):
        weld=bpy.context.view_layer.objects.active
        if (weld.weld.name != None):
            if weld.weld.blend:
                if debug: print("blending on")
            else:
                if debug: print("blending off")                
            return
    return   

class WelderVariables(bpy.types.PropertyGroup):
    object: bpy.props.PointerProperty(name="object", type=bpy.types.Object)   

class WelderSettings(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty()
    blend: bpy.props.BoolProperty(name="Surface blend", description="Surface blend", default=False, update=surfaceBlendUpdate)
    thumbnails: bpy.props.EnumProperty(items=[])

def generate_previews(redraw=False):
    enum_items = []
    if redraw:
        enum_items.append(("test", "test", "", 0, 0))
    else:    
        # We are accessing all of the information that we generated in the register function below
        pcoll = preview_collections["thumbnail_previews"]
        image_location = pcoll.images_location
        VALID_EXTENSIONS = ('.png', '.jpg', '.jpeg')
            
        # Generate the thumbnails
        for i, image in enumerate(os.listdir(image_location)):
            if image.endswith(VALID_EXTENSIONS):
                filepath = os.path.join(image_location, image)
                thumb = pcoll.load(filepath, filepath, 'IMAGE')
                enum_items.append((image, image, "", thumb.icon_id, i))
                    
    return enum_items 

bpy.types.Scene.weldsmooth=bpy.props.BoolProperty(
    name="weldsmooth", description="weldsmooth", default=False)
bpy.types.Scene.welddrawing=bpy.props.BoolProperty(
    name="welddrawing", description="welddrawing", default=False)
bpy.types.Scene.shapemodified=bpy.props.BoolProperty(
    name="shapemodified", description="shapemodified", default=False)     
preview_collections = {}
curve_node_mapping = {}
bpy.types.Scene.shapebuttonname=bpy.props.StringProperty(name="Shape button name", default="Modify")
pcoll = bpy.utils.previews.new()
simplify_error=0.001
lattice_error_thresh=0.0001
images_path = pcoll.images_location = os.path.join(os.path.dirname(__file__), "welder_images")
pcoll.images_location = bpy.path.abspath(images_path)
preview_collections["thumbnail_previews"] = pcoll
bpy.types.Scene.my_thumbnails = EnumProperty(items=generate_previews())

def weldchose(iconname):
    if iconname=='icon_1.png': return 'Weld_1'
    if iconname=='icon_2.png': return 'Weld_2'
    if iconname=='icon_3.png': return 'Weld_3'
    if iconname=='icon_4.png': return 'Weld_4'
    if iconname=='icon_5.png': return 'Weld_5'
    if iconname=='icon_6.png': return 'Weld_6'
    if iconname=='icon_7.png': return 'Weld_7'
    return ''    

def switchkeymap(state):
    x = bpy.context.window_manager.keyconfigs[2].keymaps['3D View'].keymap_items
    y=bpy.context.window_manager.keyconfigs[2].keymaps['3D View Tool: Select Box'].keymap_items
    z=bpy.context.window_manager.keyconfigs[2].keymaps['Object Mode'].keymap_items
    list = [keymap for keymap in x if keymap.type == 'LEFTMOUSE' or keymap.type == 'RIGHTMOUSE' or keymap.type == 'EVT_TWEAK_L' or keymap.type == 'ACTIONMOUSE' or keymap.type == 'SELECTMOUSE']
    listy=[keymap for keymap in y]
    listz = [keymap for keymap in z if keymap.type == 'LEFTMOUSE' or keymap.type == 'RIGHTMOUSE' or keymap.type == 'EVT_TWEAK_L' or keymap.type == 'ACTIONMOUSE' or keymap.type == 'SELECTMOUSE']
    for km in list: km.active = state
    for km in listy: km.active = state
    for km in listz: km.active = state


def draw_callback_px(self, context):

    shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
    bgl.glEnable(bgl.GL_BLEND)
    bgl.glEnable(bgl.GL_LINE_SMOOTH)
    bgl.glLineWidth(3)

    batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": self.mouse_path})
    shader.bind()
    shader.uniform_float("color", (0.0, 0.0, 0.0, 0.5))
    batch.draw(shader)

    """
    for x,y,z in self.mouse_path:        
        bgl.glVertex3f(x, y,z)
    bgl.glEnd()
    """
    # restore opengl defaults
    bgl.glLineWidth(1)
    bgl.glDisable(bgl.GL_BLEND)
  
def get_origin_and_direction(self,event,context):
    region=context.region
    region_3d=context.space_data.region_3d
    mouse_coord=(event.mouse_region_x,event.mouse_region_y)
    #vector = region_2d_to_vector_3d(region, region_3d, mouse_coord)
    origin=region_2d_to_origin_3d(region,region_3d,mouse_coord)
    #direction=region_2d_to_location_3d(region, region_3d, mouse_coord, vector)    
    direction=region_2d_to_vector_3d(region, region_3d, mouse_coord)  
    return origin,direction

def get_mouse_3d_on_mesh(self,event,context):
    origin,direction=get_origin_and_direction(self,event,context)
    #following is for 2.91
    depsgraph = context.evaluated_depsgraph_get()
    self.ishit,self.hit,self.normal, *_ =context.scene.ray_cast(depsgraph,origin,direction)
    #following works in 2.8
    #self.ishit,self.hit,self.normal, *_ =context.scene.ray_cast(bpy.context.view_layer,origin,direction)
    return self.ishit,self.hit

def bvhtree_from_object(self, context, object):
    bm = bmesh.new()
    mesh = object.data
    bm.from_mesh(mesh)
    bm.transform(object.matrix_world)
    bvhtree = BVHTree.FromBMesh(bm)
    return bvhtree

def WeldNodeTree():
    if 'WeldCurveData' not in bpy.data.node_groups:
        ng = bpy.data.node_groups.new('WeldCurveData', 'ShaderNodeTree')
        #ng.fake_user = True
    return bpy.data.node_groups['WeldCurveData'].nodes

def WeldCurveData(curve_name,self):
    if curve_name not in curve_node_mapping:    
        cn = WeldNodeTree().new('ShaderNodeRGBCurve')     
        curve_node_mapping[curve_name] = cn.name 
   # bpy.data.node_groups['WeldCurveData'].nodes[curve_node_mapping["WeldCurve"]].mapping.curves[3].points[0].location
   # bpy.data.node_groups['WeldCurveData'].nodes[curve_node_mapping["WeldCurve"]].mapping.curves[3].points.new(1,0.5)   
   # bpy.data.node_groups['WeldCurveData'].nodes[curve_node_mapping["WeldCurve"]].mapping.curves[3].points.new(0,0.5)   
    return WeldNodeTree()[curve_node_mapping[curve_name]]

class PANEL_PT_WelderToolsPanel(bpy.types.Panel):
    bl_label = "Welder"
    bl_idname = "OBJECT_PT_Welder"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Welder"
 
    active=False 
    weld=None
 
    @classmethod
    def poll(self, context):
        if (context.active_object != None):
            if bpy.context.view_layer.objects.active.get('Weld') is not None:         
                self.weld=bpy.context.view_layer.objects.active           
                self.active= True
            else:
                self.active= False
        else:
            self.active= True            
        return True        
 
    def draw(self, context):
        if (self.active):
            try:
                #row=self.layout.row()
                #row.template_icon_view(self.weld.weld, "thumbnails") #add interactive and updatemethod
                row=self.layout.row()
                #row.prop(self.weld.weld,"name")
                row=self.layout.row()
                row.prop(getSpline(),"use_cyclic_u",text="cyclic")
                #row.prop(self.weld.weld, "blend")
            except:
                pass    
            '''
            row.template_icon_view(context.scene, "my_thumbnails")
            row.enabled=not bpy.context.scene.welddrawing
            row=self.layout.row()
            row.operator("weld.weld")
            row.enabled=not bpy.context.scene.welddrawing
            row=self.layout.row()
            row.operator("weld.draw")
            row.enabled=not bpy.context.scene.welddrawing
            row=self.layout.row()
            
            row.prop(context.scene, "surfaceblend")
            row=self.layout.row()
            row.prop(context.scene, 'type', expand=True) 
            ''' 
        else:
            row=self.layout.row()
            row.template_icon_view(context.scene, "my_thumbnails")
            row.enabled=not bpy.context.scene.welddrawing
            row=self.layout.row()
            row.operator("weld.weld")
            row.enabled=not bpy.context.scene.welddrawing
            row=self.layout.row()
            row.operator("weld.draw")
            row.enabled=not bpy.context.scene.welddrawing
            row=self.layout.row()
            row.prop(context.scene, "cyclic")
            row.prop(context.scene, "surfaceblend")
            row=self.layout.row()
            row.prop(context.scene, 'type', expand=True)          
        
class PANEL_PT_WelderSubPanelDynamic(bpy.types.Panel):        
    bl_label = "Shape"
    bl_idname = "OBJECT_PT_Welder_dynamic"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Welder"

    
    @classmethod
    def poll(cls, context):
        if (context.active_object != None):
            if bpy.context.view_layer.objects.active.get('Weld') is not None:                
                return True
            else: return False
        else: return False
    
    def draw(self, context):  
        #bpy.context.scene.cyclic=cehckIfCyclic()
        row=self.layout.row()
        row.operator("weld.shape", text=bpy.context.scene.shapebuttonname)
        box = self.layout.box() 
        box.enabled= bpy.context.scene.shapemodified 
        box.row()
        if bpy.context.scene.shapemodified: box.template_curve_mapping(WeldCurveData('WeldCurve',self), "mapping")   
        else: removenode()
        row=self.layout.row()
        row.operator("weld.optimize")     

def update_welder_category(self, context):
    try:
        bpy.utils.unregister_class(PANEL_PT_WelderToolsPanel)
        bpy.utils.unregister_class(PANEL_PT_WelderSubPanelDynamic)
    except:
        pass
    PANEL_PT_WelderToolsPanel.bl_category = context.preferences.addons[__name__].preferences.category
    PANEL_PT_WelderSubPanelDynamic.bl_category = context.preferences.addons[__name__].preferences.category
    bpy.utils.register_class(PANEL_PT_WelderToolsPanel)
    bpy.utils.register_class(PANEL_PT_WelderSubPanelDynamic) 

class WelderPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__
    prefs_tabs: EnumProperty(
    items=(('info', "Info", "Welder Info"),
           ('options', "Options", "Welder Options")),
    default='info')
    
    category : StringProperty(description="Choose a name for the category of the panel",default="Welder", update=update_welder_category)

    def draw(self, context):
        wm = context.window_manager
        layout = self.layout

        row= layout.row(align=True)
        row.prop(self, "prefs_tabs", expand=True)
        if self.prefs_tabs == 'info':
            layout.label(text="1. Welding along intersection")
            layout.label(text="- select 2 objects in object mode,")
            layout.label(text="- choose what type of weld you want to place (Geometry/Decal)")
            layout.label(text="- click 'Weld' button")
            layout.label(text="- adjust scale by moving the mouse (LMB to apply, RMB sets to default scale)")
            layout.label(text="- adjust rotation by moving the mouse (LMB to apply, RMB sets to default rotation)")
            layout.label(text="2. Welding along selected edgeloop")
            layout.label(text="- select desired edgeloop in edit mode, ")
            layout.label(text="- choose what type of weld you want to place (Geometry/Decal)")
            layout.label(text="- click 'Weld' button")
            layout.label(text="- adjust scale by moving the mouse (LMB to apply, RMB sets to default scale)")
            layout.label(text="- adjust rotation by moving the mouse (LMB to apply, RMB sets to default rotation)")
            layout.label(text="3. Draw welds")
            layout.label(text="- click 'Draw' button while in object mode")
            layout.label(text="- draw on the model's surface")
            layout.label(text="- click RMB or Enter in order to finish drawing and place weld")
            layout.label(text="- adjust scale by moving the mouse (LMB to apply, RMB sets to default scale)")
            layout.label(text="- adjust rotation by moving the mouse (LMB to apply, RMB sets to default rotation)")
            layout.label(text="4. Profile editing")
            layout.label(text="- select weld,")
            layout.label(text="- click 'Modify; button")
            layout.label(text="- adjust weld's profile by playing with curve widget")
            layout.label(text="- click 'Apply' button to accept results")
    
        if self.prefs_tabs == 'options':
            box = layout.box()    
            row = box.row(align=True)
            row.label(text="Panel Category:")
            row.prop(self, "category", text="")
             
classes =(
PANEL_PT_WelderToolsPanel,
PANEL_PT_WelderSubPanelDynamic,
OBJECT_OT_WeldButton,
WelderPreferences,
OBJECT_OT_WeldTransformModal,
OBJECT_OT_WelderDrawOperator,
OBJECT_OT_ShapeModifyButton,
OBJECT_OT_ShapeModifyModal,
OBJECT_OT_OptimizeButton,
WelderVariables,
WelderSettings
)
bpy.types.Scene.cyclic=bpy.props.BoolProperty(name="cyclic", description="cyclic",default=True)
bpy.types.Scene.surfaceblend=bpy.props.BoolProperty(name="Surface blend", description="Surface blend",default=False)
bpy.types.Scene.type=bpy.props.EnumProperty(items=[
    ("Geometry", "Geometry", "Geometry", 0),
    ("Decal", "Decal", "Decal", 1),
    ])

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    context = bpy.context
    prefs = context.preferences.addons[__name__].preferences
    update_welder_category(prefs, context)       
    bpy.types.Object.weld = bpy.props.PointerProperty(type=WelderSettings)

def unregister():
    for cls in classes:
        if debug: print(cls)
        bpy.utils.unregister_class(cls)
    #bpy.utils.unregister_class(PANEL_PT_WelderToolsPanel)
    