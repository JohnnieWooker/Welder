
NAME="Welder"
DECAL_SUFFIX="_decal"
PROXY_SUFFIX="_proxy"
WELD_FILE="weld.blend"
INTERSECTION_COLLECTION_NAME="TemporaryIntersectors"

class Weld:
    def __init__(self, name, iconpath):
        self.name = name
        self.iconpath = iconpath
